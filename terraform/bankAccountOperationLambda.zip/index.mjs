import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, GetCommand } from "@aws-sdk/lib-dynamodb";
import { KMSClient, EncryptCommand, DecryptCommand } from "@aws-sdk/client-kms";
import { v4 as uuidv4 } from 'uuid';
// Initialize DynamoDB Document Client and KMS client
const ddbClient = DynamoDBDocumentClient.from(new DynamoDBClient({ region: process.env.REGION }));
const kmsClient = new KMSClient({ region: process.env.REGION });

export const handler = async (event) => {
  try {
    const method = event.requestContext.http.method;
    if (method === "POST") {
      const { userId, accounts } = JSON.parse(event.body);

      // Convert accounts data to string and buffer
      const accountsString = JSON.stringify(accounts);
      const accountsBuffer = Buffer.from(accountsString);

      // Encrypt the accounts data using KMS
      const encryptParams = {
        KeyId: process.env.KMS_KEY_ARN, // The KMS key ARN from environment variables
        Plaintext: accountsBuffer,
      };
      const encryptCommand = new EncryptCommand(encryptParams);
      const encryptedData = await kmsClient.send(encryptCommand);

      // Prepare DynamoDB item with encrypted data
      const ddbParams = {
        TableName: process.env.DYNAMODB_TABLE_NAME,
        Item: {
          userId, // Partition key
          accounts: encryptedData.CiphertextBlob, // Encrypted accounts data
        },
      };

      // Use PutCommand to store the item in DynamoDB
      const putCommand = new PutCommand(ddbParams);
      await ddbClient.send(putCommand);

      return {
        statusCode: 200,
        body: JSON.stringify({ message: "Data encrypted and stored successfully." }),
      };
    } else if (method === "GET") {
      const userId = event.queryStringParameters.userId;

      // Retrieve the item from DynamoDB
      const ddbParams = {
        TableName: process.env.DYNAMODB_TABLE_NAME,
        Key: { userId }, // Partition key
      };
      const getCommand = new GetCommand(ddbParams);
      const result = await ddbClient.send(getCommand);

      if (!result.Item) {
        return {
          statusCode: 201,
          body: JSON.stringify({ message: "Item not found." }),
        };
      }

      // Decrypt the accounts data using KMS
      const decryptParams = {
        CiphertextBlob: result.Item.accounts, // Encrypted accounts data from DynamoDB
      };
      const decryptCommand = new DecryptCommand(decryptParams);
      const decryptedData = await kmsClient.send(decryptCommand);

      // Convert decrypted data back to a string and parse JSON
      const accountsBuffer = decryptedData.Plaintext;
      const accountsString = Buffer.from(accountsBuffer).toString("utf-8"); // Proper conversion

      // Parse the JSON string
      const accounts = JSON.parse(accountsString);
      accounts.forEach((account) => {
        account.transactions = generateMockTransactions();
      });
      return {
        statusCode: 200,
        body: JSON.stringify({ userId, accounts }),
      };
    } else {
      return {
        statusCode: 405,
        body: JSON.stringify({ message: "Method not allowed." }),
      };
    }
  } catch (error) {
    console.error("Error processing request:", error);

    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Failed to process request.", error: error.message }),
    };
  }
};

const generateMockTransactions = () => {
  const transactionNames = [
    'Grocery Store',
    'Online Shopping',
    'Restaurant',
    'Utility Bill',
    'Subscription Service',
    'ATM Withdrawal',
    'Transportation',
    'Rent Payment',
    'Gym Membership',
    'Movie Tickets',
    'Clothing',
    'Insurance'
  ];

  const paymentChannels = ['Bank Transfer', 'Credit Card', 'Debit Card', 'PayPal', 'Cash'];
  const categories = ['Food', 'Entertainment', 'Bills', 'Transportation', 'Rent', 'Shopping', 'Health', 'Miscellaneous', 'Insurance'];
  const transactionTypes = ['debit', 'credit'];
  
  const getRandomElement = (array) => array[Math.floor(Math.random() * array.length)];
  const getRandomAmount = () => (Math.random() * 1000).toFixed(2);
  const getRandomDate = () => {
    const daysAgo = Math.floor(Math.random() * 30);
    return new Date(new Date().setDate(new Date().getDate() - daysAgo));
  };

  const transactions = Array.from({ length: 15 }, () => {
    const type = getRandomElement(transactionTypes);
    const amount = type === 'debit' ? `-${getRandomAmount()}` : getRandomAmount();
    
    return {
      id: uuidv4(),
      name: getRandomElement(transactionNames),
      amount: parseFloat(amount),
      type,
      date: getRandomDate(),
      paymentChannel: getRandomElement(paymentChannels),
      category: getRandomElement(categories),
    };
  });

  return transactions;
};
