const { Configuration, PlaidApi, PlaidEnvironments } = require("plaid");

const configuration = new Configuration({
  basePath: PlaidEnvironments.sandbox,
  baseOptions: {
    headers: {
      "PLAID-CLIENT-ID": process.env.PLAID_CLIENT_ID,
      "PLAID-SECRET": process.env.PLAID_SECRET,
    },
  },
});

const plaidClient = new PlaidApi(configuration);

module.exports.handler = async (event) => {
  try {
    const http = event.requestContext.http;
    const path = http.path;
    const method = http.method;

    // Common response headers
    const headers = {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*", // Enable CORS if required
    };

    // Parse the request body
    const body = event.body ? JSON.parse(event.body) : {};

    // Route based on path
    if (path === "/hello" && method === "POST") {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ message: "hello " + body.name }),
      };
    }

    if (path === "/dev/create-link-token" && method === "POST") {
      const user = JSON.parse(event.body);
      const plaidRequest = {
        user: {
          client_user_id: user.sub,
        },
        client_name: user.email,
        products: ["auth"],
        language: "en",
        country_codes: ["US"],
      };

      const createTokenResponse = await plaidClient.linkTokenCreate(
        plaidRequest
      );

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(createTokenResponse.data),
      };
    }

    if (path === "/auth" && method === "POST") {
      const accessToken = body.access_token;
      const plaidRequest = { access_token: accessToken };
      const plaidResponse = await plaidClient.authGet(plaidRequest);

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(plaidResponse.data),
      };
    }

    if (path === "/dev/exchange-public-token" && method === "POST") {
      const body = JSON.parse(event.body);
      const publicToken = body.public_token;
      // Exchange public token for access token and item ID
      const response = await plaidClient.itemPublicTokenExchange({
        public_token: publicToken,
      });

      const accessToken = response.data.access_token;
      const itemId = response.data.item_id;

      // Get account information from Plaid using the access token
      const accountsResponse = await plaidClient.accountsGet({
        access_token: accessToken,
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          userId: body.userId,
          bankId: itemId,
          accounts: accountsResponse.data.accounts,
          accessToken,
        }),
      };
    }

    return {
      statusCode: 404,
      headers,
      body: JSON.stringify({ message: "Not Found" }),
    };
  } catch (error) {
    console.error("Error:", error);

    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ message: "Internal Server Error" }),
    };
  }
};
